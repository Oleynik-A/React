import React, { useState } from "react";

import { GoldenLayoutComponent } from "./goldenLayoutComponent";
import { MyGoldenPanel } from "./myGoldenPanel";

function App() {
  const [contentItems] = useState([
    {
      title: "A react component",
      type: "react-component",
      component: "testItem",
      color: "#F15C25",
      props: { value: "I'm on the left" }
    },
    {
      title: "Another react component",
      type: "react-component",
      component: "testItem"
    },
    {
      title: "Another react component",
      type: "react-component",
      component: "testItem"
    }
  ]);

  return (
    <div>
      <GoldenLayoutComponent //config from simple react example: https://golden-layout.com/examples/#qZXEyv
        htmlAttrs={{ style: { height: "500px", width: "100%" } }}
        config={{
          content: [
            {
              type: "stack",
              content: contentItems
            }
          ]
        }}
        registerComponents={myLayout => {
          myLayout.registerComponent("testItem", MyGoldenPanel);
          myLayout.on("stateChanged", function() {
            var state = JSON.stringify(myLayout.toConfig());
            localStorage.setItem("savedState", state);
          });
        }}
      />
    </div>
  );
}

export default App;
