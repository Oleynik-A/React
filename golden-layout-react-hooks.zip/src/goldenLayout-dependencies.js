import $ from "jquery";
//import React from "react";
//import ReactDOM from "react-dom";
window.$ = $;
window.jQuery = $;
window.jquery = $;

//window.ReactDOM = ReactDOM;
//window.React = React;
