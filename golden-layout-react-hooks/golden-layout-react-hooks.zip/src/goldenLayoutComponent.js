import React from "react";
import ReactDOM from "react-dom";
import GoldenLayout from "golden-layout";
import $ from "jquery";

import "golden-layout/src/css/goldenlayout-base.css";
import "golden-layout/src/css/goldenlayout-dark-theme.css";

export class ReactGoldenLayout extends React.Component {
	state = {};
	containerRef = React.createRef();
	goldenLayoutInstance = undefined;

	render () {
		const { containerRef, loadChildren } = this;
		const { htmlAttrs } = this.props;
		return (
			<div ref={ containerRef } { ...htmlAttrs }>
				{ loadChildren(this.state.renderPanels) }
			</div>
		);
	}

	resize() {
		this.goldenLayoutInstance.updateSize();
	}

	componentDidMount () {
		const { config = {}, registerComponents } = this.props;
		this.resize = this.resize.bind(this);
		const goldenLayoutInstance = new GoldenLayout(
			config,
			this.containerRef.current
		);
		if (registerComponents instanceof Function) {
			registerComponents(goldenLayoutInstance);
		}
		goldenLayoutInstance.reactContainer = this;
		goldenLayoutInstance.init();
		this.goldenLayoutInstance = goldenLayoutInstance;
		window.addEventListener("resize", this.resize);
	}

	componentWillUnmount () {
		window.removeEventListener("resize", this.resize);
	}

	loadChildren (renderPanels) {
		let panels = Array.from(renderPanels || []);
		return panels.map((panel) => {
			return ReactDOM.createPortal(
				panel._getReactComponent(),
				panel._container.getElement()[0]
			);
		});
	}

	componentRender (reactComponentHandler) {
		this.setState(state => {
			let newRenderPanels = new Set(state.renderPanels);
			newRenderPanels.add(reactComponentHandler);
			return { renderPanels: newRenderPanels };
		});
	}

	componentDestroy (reactComponentHandler) {
		this.setState(state => {
			let newRenderPanels = new Set(state.renderPanels);
			newRenderPanels.delete(reactComponentHandler);
			return { renderPanels: newRenderPanels };
		});
	}

}

const ReactComponentHandler = GoldenLayout["__lm"].utils.ReactComponentHandler;

class ReactComponentHandlerPatched extends ReactComponentHandler {
	_render () {
		const reactContainer = this._container.layoutManager.reactContainer; //Instance of ReactGoldenLayout class
		if (reactContainer && reactContainer.componentRender) {
			reactContainer.componentRender(this);
		}
	}

	_destroy () {
		ReactDOM.unmountComponentAtNode( this._container.getElement()[ 0 ] );
		this._container.off("open", this._render, this);
		this._container.off("destroy", this._destroy, this);
	}

	_getReactComponent () {
		//the following method is absolute copy of the original, provided to prevent dependency on window.React
		const defaultProps = {
			glEventHub: this._container.layoutManager.eventHub,
			glContainer: this._container
		};
		const props = $.extend(defaultProps, this._container._config.props);
		return React.createElement(this._reactClass, props);
	}
}

GoldenLayout["__lm"].utils.ReactComponentHandler = ReactComponentHandlerPatched;
