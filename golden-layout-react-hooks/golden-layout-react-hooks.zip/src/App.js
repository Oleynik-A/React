import React, { useCallback } from "react";

import { ReactGoldenLayout } from "./goldenLayoutComponent";
import { MyGoldenPanel } from "./myGoldenPanel";

function App() {
  const config = {
    content: [
      {
        type: "row",
        content: [
          {
            title: "A react component",
            type: "react-component",
            component: "MyGoldenPanel",
            color: "#F15C25",
          },
          {
            title: "Another react component",
            type: "react-component",
            component: "MyGoldenPanel"
          },
          {
            title: "Another react component",
            type: "react-component",
            component: "MyGoldenPanel"
          }
        ]
      }
    ]
  }
	const registerComponentCallback = useCallback((myLayout) => {
		myLayout.registerComponent("MyGoldenPanel", MyGoldenPanel);
		myLayout.on("stateChanged", function () {
			const state = JSON.stringify(myLayout.toConfig());
			localStorage.setItem("savedState", state);
		});
	});

  return (
    <div>
      <ReactGoldenLayout //config from simple react example: https://golden-layout.com/examples/#qZXEyv
        htmlAttrs={{ style: { height: "500px", width: "100%" } }}
        config={config}
        registerComponents={registerComponentCallback}
      />
    </div>
  );
}

export default App;
