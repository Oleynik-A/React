import React from "react";

export function MyGoldenPanel () {
	return <div>
		ODC is me.
	</div>;
}