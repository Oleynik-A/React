const tileData = [
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Breakfast',
        author: 'jill111',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Tasty burger',
        author: 'director90',
    },
    {
        img: 'http://via.placeholder.com/600x400',
        title: 'Camera',
        author: 'Danson67',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Morning',
        author: 'fancycrave1',
    },
    {
        img: 'http://via.placeholder.com/600x400',
        title: 'Hats',
        author: 'Hans',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Honey',
        author: 'fancycravel',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Vegetables',
        author: 'jill111',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Water plant',
        author: 'BkrmadtyaKarki',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Mushrooms',
        author: 'PublicDomainPictures',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Olive oil',
        author: 'congerdesign',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Sea star',
        author: '821292',
    },
    {
        img: 'http://via.placeholder.com/500x330',
        title: 'Bike',
        author: 'danfador',
    },
];

export default tileData;
