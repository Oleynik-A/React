import React from 'react';
import Avatar from 'material-ui/Avatar';
import Chip from 'material-ui/Chip';
import FaceIcon from 'material-ui-icons/Face';
import Done from 'material-ui-icons/Done';
import CardBox from 'components/CardBox';
import ContainerHeader from 'components/ContainerHeader'
import ChipsArray from './chipArray/ChipsArray';
import ChipsWithInputBox from "./chipsWithInputBox/ChipsWithInputBox";

function handleRequestDelete() {
    alert('You clicked the delete icon.'); // eslint-disable-line no-alert
}

function handleClick() {
    alert('You clicked the Chip.'); // eslint-disable-line no-alert
}

const Chips = ({match}) => {
    return (
        <div className="animated slideInUpTiny animation-duration-3">
            <ContainerHeader title="Chips" match={match} />

            <div className="row mb-md-4">
                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Default Chip"
                >
                    <Chip label="Default" />

                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12 text-center"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Outline Chip"
                >
                    <Chip label="Outline Chip" className="chip-outline" />
                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Chip With Text Avatar"
                >
                    <Chip avatar={<Avatar>MS</Avatar>} label="Text Avatar" />
                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Clickable Chip"
                >
                    <Chip label="I’m Clickable" onClick={handleClick} />
                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Chip With Image Avatar"
                >
                    <Chip avatar={<Avatar src="http://via.placeholder.com/256x256" />} label="Image Avatar" />
                </CardBox>
                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Deletable Chip"
                >
                    <Chip
                        avatar={<Avatar src="http://via.placeholder.com/256x256" />}
                        label="Deletable Chip"
                        onDelete={handleRequestDelete}
                    />
                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Chip With Icon Avatar"
                >
                    <Chip
                        avatar={
                            <Avatar>
                                <FaceIcon className="bg-gray lighten-3 " />
                            </Avatar>
                        }
                        label="Icon Avatar"
                    />
                </CardBox>

                <CardBox
                    styleName="col-lg-3 col-md-4 col-sm-6 col-12"
                    cardStyle="text-center"
                    childrenStyle="d-flex justify-content-center"
                    heading="Custom Clickable Chip"
                >
                    <Chip
                        label="I’m Custom Clickable"
                        onClick={handleClick}
                        onDelete={handleRequestDelete}
                        deleteIcon={<Done />}
                    />
                </CardBox>
            </div>

            <div className="row mb-md-4">
                <CardBox styleName="col-lg-12" heading="Chip Array">
                    <ChipsArray />
                </CardBox>
            </div>

            <div className="row mb-md-4">
                <CardBox styleName="col-xl-12" heading="Chips Implementation With Input Box">
                    <ChipsWithInputBox />
                </CardBox>
            </div>
        </div>
    );
};

export default (Chips);

