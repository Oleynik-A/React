/**
 * src/main.js
 * Author: H.Alper Tuna <halpertuna@gmail.com>
 * Date: 16.09.2016
 */

import MetisMenu from './components/MetisMenu';

export default MetisMenu;
